
function displaymessage(){
alert("hello");
}
function product(){
var c=document.getElementById("txt1").value+document.getElementById("txt2").value;
document.getElementById("dev").innerHTML=c;
}
function sumArray(arr){
var sum=0;
for(counter in arr){
sum=sum+arr[counter]
}
return sum;}
function date(){
var dat=new Date();
document.getElementById("d").innerHTML=dat.getFullYear();
}
