
List<String> l=new LinkedList<String>()
String name=null
l.add("kavita")
l.add("bora navhvjv")
l.eachWithIndex{p,i->
if(i%2!=0)
l.remove(i)
else
println "fbk"}
//}
//if("$name")
//println "dsd"
//else
//println "bfjm"