int i=1
4.times{
i.times{
print "*"
}
i=i*2
println ""
}