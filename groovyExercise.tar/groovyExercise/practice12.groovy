File fe=new File("/home/kavita/removespace.txt")
File f=new File("/home/kavita/kavitabora1.groovy")
fe.createNewFile()
String l=""

       f.eachLine{
     l+=it.replaceAll("\\s","")
       
        }
    fe<<l
    