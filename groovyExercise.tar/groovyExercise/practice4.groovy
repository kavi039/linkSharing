class Gstringex{
int age=20;
String name="vfvdn"
String add="working in intelligrape"
String toString(){
return "hello,${name+add+age}"
}
}
println(new Gstringex().toString())