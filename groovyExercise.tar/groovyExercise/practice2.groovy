class Person{
String name
Integer age
String address
String getName(){
return "x"
}
}
class Personextend extends Person{
int empid
String company
int salary
int getEmpid(){
return 0;
}

                void setEmpid(int empid){
                  this.empid=empid
                }
                         }
Person p=new Personextend()
p.name="kavita"
p.age=23
p.address="sfcjhg"
p.empid=34
//p.@empid=45
println "EmpId>>>>>>"+p.getEmpid()
println "AGE ?>>>> "+p.name+" EmpId>>>>>>"+p.@empid