byte []b=new File("/home/kavita/Downloads/clock0.png").getBytes()
File newFile=new File("/home/kavita/Downloads/clock1.png")
newFile.createNewFile()
newFile.setBytes(b)

println "<<<<............................................>>>>"

//newFile.eachLine{println it}