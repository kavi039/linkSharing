class Person{
String name
Integer age
String address
}
Person p=new Person(name:"kavita",age:23,address:"vchdchgbjdhv")
println p.name+" "+p.age+" "+p.address
println (p.getName()+" "+p.getAge()+" "+p.getAddress())