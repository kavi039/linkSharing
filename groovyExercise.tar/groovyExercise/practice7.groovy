int i=1
10.times{println 3*i 
i++}



Range r=1..10
r.each{println it*3}
