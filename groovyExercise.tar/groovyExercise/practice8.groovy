List l=[1,2,3,4,5]
def finds={a,b->
a.contains(b)? true: false
}
println finds(l,9)