class HourMinut{
Integer hour,mint
String minus(HourMinut m)
{
Integer i=Math.abs(hour*60+mint-(m.mint+m.hour*60))
return ((int)i/60)+"hour" +" "+i%60+"mint" 
}
String plus(HourMinut m)
{
Integer i=hour*60+m.hour*60+mint+m.mint
return ((int)i/60)+"hour" +" "+i%60+"mint" 
}
}
HourMinut hm=new HourMinut(hour:1,mint:90)
HourMinut hn=new HourMinut(hour:1,mint:00)
print hm+hn
print hm-hn