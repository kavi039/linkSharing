/*Groovy Truth: if('test') { printlnn "test evaluated to true inside if" }
try replacing test with various objects and observe its behaviour.
a) "Test"
b)'null'
c) null
d) 100
e) 0
f) empty list
g) list with all vaues as null List list = new ArrayList()*/
if('test')
println "test evaluated 1"
println "///////////////////"
if("test")
println "test evaluated 2"
println "//////////////"
if('null')
println "null is evaluated 3"
println "///////////////////"
if(null)
println "null is evaluated 4"
println "//////////////"
if(100)
println "100 is evaluated 5"
println "///////////////////"
if(0)
println "0 is evaluated 6"
println "//////////////"
List l
if(l)
println "l is evaluated 7"
println "///////////////////"
l=new ArrayList()
if(l)
println "l is evaluated 8"
println "//////////////"
