File f2=new File("abc.txt")
f2.createNewFile()

File f=new File("kavitabora.groovy")
int i=1;
f.eachLine{if(i%2!=0) {
f2<< i+""+it+"\n"
i++
}
i++}



