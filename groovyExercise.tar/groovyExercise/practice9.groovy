def dir=new File("/home/kavita/javascript") 
List<String> l=new ArrayList<String>()


dir.eachFileRecurse{if(it.isFile())
          
           l.add(it)
    }
    File f=new File("kavitabora.groovy")
   l.each{ it.eachLine{f<<(it+"\n")}}
   f.eachLine{println it}
    
    
   