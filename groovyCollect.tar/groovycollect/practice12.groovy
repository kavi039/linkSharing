Range r='a'..'z'

println 'k'..'z'