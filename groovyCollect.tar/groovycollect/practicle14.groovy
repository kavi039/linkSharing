for(int i=1;i<=100;i++)
{
if(i%3==0&&i%5==0)
println "Fizzbizz"

else if(i%3==0)
println "Fizz"
else if(i%5==0)
println "bizz"
else 
println i}