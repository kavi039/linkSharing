class Stacks{
List l=new ArrayList()
void push(def ob){
l.push(ob)}
def pop(){
return l.pop()
}
def top(){
return l.last()
}
}
Stacks s=new Stacks()
s.l<<"vnv"<<"kavita"<<"1234"
println s.pop()
println s.top()
s.push(new Stacks())
println s.top()
