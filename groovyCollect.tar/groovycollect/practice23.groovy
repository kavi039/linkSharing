class Employee{
String name
int age
String depname
int empno
int salary
String toString(){
return "employee name:${name} age:${age} depname ${depname} empno ${empno} empsalary ${salary} "
}
}
List l=new ArrayList()
l.add(new Employee(name:"kavitaBora",age:29,depname:"Computing1",salary:20))
l.add(new Employee(name:"kbc",age:36,depname:"Computing2",salary:1))
l.add(new Employee(name:"cdef",age:23,depname:"Computing1",salary:9000))
l.add(new Employee(name:"ghij",age:17,depname:"Computing1",salary:1000))
//l.any{if(it.salary<=5000&&it.salary>=0)
//println it}
                         //23(a)
Map m2=l.groupBy{it.salary}
 m2.each{k,v->\
 if(k<=5000&&k>=0)
 println  "salary b/w 0 and 5000 ${v}"
 else if(k<=10000&&k>=5001)
 println "salary b/w 5001 and 10000 ${v}"
 }
                    println "////////////////////////////////////"

//23(b)
Map m=l.groupBy{it.depname}
m.each{println "department ${it.key} ${it.value.size()}"}
println "////////////////////////////////////////"
                                              
                                                
                                                //23(c)Get the list of employees whose age is between 18 and 35
                                                println "////23(c)"
                                                l.each{
                                               if(it.age>18&&it.age<35)
                                                println it
                                                }

 
 println "////////////////////"
 //22(d)
    m2=l.groupBy{it.name[0]}
   m2.each{
   println "employee  whose name start with   ${it.key}  and age is greater than 20"
 it.value.groupBy{it.age>=20}.each{
 if(it.key==true)
 println it.value.size()
 }
    }
   
 
 
//23(e)
m.each{
println "department : ${it.key}"
it.value.each{
println it.name
}
}
println "/////////////////////////////////////"

                                              
  
    
    
     