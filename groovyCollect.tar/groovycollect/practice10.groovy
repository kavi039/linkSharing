Range r=1..10
println r.first()+"  "+r.get(1)+"  "+r.last()