List l1=[3,4,5,6]
List l2=[13,15,8]
List l3=l2.intersect(l1)
if(l3)
println "both list contain common element"
else
println "both have different element"