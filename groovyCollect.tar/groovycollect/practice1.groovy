Range r=1..10

r.each{
if(it%2==0)
println it
}