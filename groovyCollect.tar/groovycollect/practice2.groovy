List l1=[1,2,3,4,5,3,2,1]
Set s=l1 as Set
println l1.unique()