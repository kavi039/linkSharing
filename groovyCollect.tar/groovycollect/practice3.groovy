List l1= [11, 12, 13, 14] 
List l2= [13, 14, 15]
println l1-l2