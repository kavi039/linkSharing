List l=new LinkedList()
l<<1<<3<<6<<1<<3
l.unique()
println l
//Set m=l as Set
//println m

 