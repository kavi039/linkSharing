String s = "this string needs to be split"
println s.tokenize(" ")
println s.tokenize()


//Compare this with the following code:
String s1 = "this string needs to be split"
println s1.split(" ")
println s1.split(/\s/) //(Try Same Parameter with tokenize)

//Also try the following exercise:
String s2 = "are.you.trying.to.split.me.mister?"
println s2.tokenize(".")
println s2.split(".")
