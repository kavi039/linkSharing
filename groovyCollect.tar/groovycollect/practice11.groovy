Range r=1..10
r.each{print "${it*2} "}

println "..................."
r.each{print "${it*12} "}