class Employee{
String name
int age
double salary
}
//List age=new ArrayList()
List em=new ArrayList()
em<<new Employee(name:"kavita10",age:10,salary:150)<<new Employee(name:"kavita1",age:12,salary:1500)<<new Employee(name:"kavita2",age:13,salary:5000)<<new Employee(name:"kavita3",age:23,salary:65000)<<new Employee(name:"kavita4",age:24,salary:7000)<<new Employee(name:"kavita5",age:33,salary:8000)<<new Employee(name:"kavita6",age:43,salary:10000)<<new Employee(name:"kavita7",age:50,salary:9000)<<new Employee(name:"kavita8",age:60,salary:1000)<<new Employee(name:"kavita9",age:61,salary:1000)
println em*.name
int max=em.get(0).age,min=em.get(0).age,maxsalary=em.get(0).salary
String name1=name2=name3=em.get(0).name
for(int i=0;i<em.size;i++){
if(maxsalary<em.get(i).salary){
maxsalary=em.get(i).salary
name3=em.get(i).name
}





if(max<=em.get(i).age)
{
max=em.get(i).age
name1=em.get(i).name
}
                           if(min>=em.get(i).age)
{
min=em.get(i).age
name2=em.get(i).name
}
if(em.get(i).salary<5000)
println em.get(i).name
}

println "$max name1 $name1 $min name2  $name2  maxsalary $maxsalary name3 , $name3"