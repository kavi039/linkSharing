List l=new LinkedList()
l<<23<<34<<56
l.eachWithIndex{p,i->
if(i%2!=0)
l.remove(i)
}
println l

