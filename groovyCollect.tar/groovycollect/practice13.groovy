String str='kavita'
int count=1;
Map m=new LinkedHashMap();
for(int i=0;i<str.length();i++){
for(int j=0;j<str.length();j++){
if(i==j)
continue;
if(str[i]==str[j])
count++
}
m.put(str[i],count)
count=1
}
m.each{k,v->
println k+" "+v}