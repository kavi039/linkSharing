Map m1=[a:12,b:13]
Map m2=[c:13,d:14]
Map m3= m1+m2