Map m = ['Computing':['Computing':600,'Information Systems':300],'Engineering':['Civil':200,'Mechanical':100],'Management':['Management':800]]
//Map m=['a':12,'b':3,'c':6]
//m.groupBy{it.getKey()}
int total=0
m.each{
total=total+it.value.size()}
println "total departments are in university ${total}"
def comput=m.get('Computing')


println "total departments in computing are ${comput.size()}"
println "students are enrolled in the Civil Engineering program ${m.get('Engineering').get('Civil')}"