Map map=new HashMap()
println map.class
println map.getClass()