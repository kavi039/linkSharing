


def findValue(def key){

String str="http://www.google.com?name=johny&age=20&hobby=cricket"
str=str.substring(str.indexOf('?')+1)
List l=str.tokenize('&')
Map m=new LinkedHashMap()
l.each{
m.put( it.substring(0,it.indexOf('=')), it.substring(it.indexOf('=')+1))
}
m.get(key)


}

println findValue('name')