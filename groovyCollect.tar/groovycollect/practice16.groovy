Map<String,Integer> m=new HashMap<String,Integer>()
m.put("Aman",24)
m.put("pankaj",25)
m.put("gaurav",23)
m.put("deepak",20)
m.put("rohitKandpal",28)
m.put("komal",56)
m.put("preeti",45)
m.each{entry->
println "key is  ${entry.key}  value is ${entry.value}"
}
println "/////second method"
m.eachWithIndex{k,v->
println "key is $k   value is $v"
}
Set s=m.entrySet()
Iterator it=s.iterator()
    for(Map.Entry e:it)
    println e.getKey()+" "+e.getValue()
    



